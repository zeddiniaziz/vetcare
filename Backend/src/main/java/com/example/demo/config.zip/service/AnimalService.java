package com.example.demo.service;

import com.example.demo.model.Animal;
import com.example.demo.repository.AnimalRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AnimalService {

    private final AnimalRepository repo;

    public AnimalService(AnimalRepository repo) {
        this.repo = repo;
    }

    public Animal create(Animal a) {
        return repo.save(a);
    }

    public List<Animal> getAll() {
        return repo.findAll();
    }

    public Animal get(Long id) {
        return repo.findById(id).orElse(null);
    }

    public Animal update(Long id, Animal newAnimal) {
        Animal a = get(id);
        if (a == null) return null;

        a.setName(newAnimal.getName());
        a.setSpecies(newAnimal.getSpecies());
        a.setAge(newAnimal.getAge());
        a.setOwnerName(newAnimal.getOwnerName());
        a.setGender(newAnimal.getGender());
        return repo.save(a);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    public List<Animal> getBySpecies(String species) {
        return repo.findBySpecies(species);
    }
    
    public List<Animal> search(String species, String ownerName) {

        if (species != null && ownerName != null) {
            return repo.findBySpeciesAndOwnerName(species, ownerName);
        } else if (species != null) {
            return repo.findBySpecies(species);
        } else if (ownerName != null) {
            return repo.findByOwnerName(ownerName);
        } else {
            return repo.findAll();
        }
    }

}
